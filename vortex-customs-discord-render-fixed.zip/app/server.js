const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");
const Database = require("better-sqlite3");
const path = require("path");
const crypto = require("crypto");

const app = express();
const server = http.createServer(app);
const io = new Server(server);
const db = new Database("vortex.db");

const PORT = process.env.PORT || 3000;
const JWT_SECRET = process.env.JWT_SECRET || "CHANGE_ME_IN_RENDER";
const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID || "";
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || "";
const DISCORD_REDIRECT_URI = process.env.DISCORD_REDIRECT_URI || "";

function requestOrigin(req) {
  const proto = String(req.headers["x-forwarded-proto"] || req.protocol || "http").split(",")[0].trim();
  const host = req.get("host");
  return `${proto}://${host}`;
}

function discordRedirectUri(req) {
  return DISCORD_REDIRECT_URI || `${requestOrigin(req)}/auth/discord/callback`;
}

function setAuthCookie(res, token, maxAgeSeconds=7*24*60*60) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader("Set-Cookie", `vortex_token=${encodeURIComponent(token)}; Max-Age=${maxAgeSeconds}; Path=/; HttpOnly; SameSite=Lax${secure}`);
}

function clearAuthCookie(res) {
  const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
  res.setHeader("Set-Cookie", `vortex_token=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax${secure}`);
}

function cookieValue(req, name) {
  const raw = req.headers.cookie || "";
  const match = raw.match(new RegExp(`(?:^|;\\s*)${name}=([^;]*)`));
  return match ? decodeURIComponent(match[1]) : "";
}

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL,
  discord_id TEXT UNIQUE,
  avatar TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  custom_key TEXT
);
CREATE TABLE IF NOT EXISTS matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  host_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  mode TEXT NOT NULL,
  team_size TEXT NOT NULL,
  build_mode TEXT NOT NULL,
  region TEXT NOT NULL,
  visibility TEXT NOT NULL DEFAULT 'public',
  status TEXT NOT NULL DEFAULT 'waiting',
  max_players INTEGER NOT NULL DEFAULT 100,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  custom_key TEXT
);
CREATE TABLE IF NOT EXISTS queue (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id INTEGER NOT NULL,
  match_id INTEGER NOT NULL,
  joined_at TEXT DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(user_id, match_id)
);
`);


try { db.prepare("ALTER TABLE matches ADD COLUMN custom_key TEXT").run(); } catch {}
try { db.prepare("ALTER TABLE users ADD COLUMN discord_id TEXT").run(); } catch {}
try { db.prepare("ALTER TABLE users ADD COLUMN avatar TEXT").run(); } catch {}
try { db.prepare("CREATE UNIQUE INDEX IF NOT EXISTS idx_users_discord_id ON users(discord_id)").run(); } catch {}

app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

function auth(req, res, next) {
  const headerToken = (req.headers.authorization || "").replace(/^Bearer\s+/i, "");
  const token = headerToken || cookieValue(req, "vortex_token");
  try {
    req.user = jwt.verify(token, JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: "No autorizado" });
  }
}

function publicMatch(row) {
  const count = db.prepare("SELECT COUNT(*) c FROM queue WHERE match_id=?").get(row.id).c;
  return {...row, players: count};
}

function discordConfigured(){
  return Boolean(DISCORD_CLIENT_ID && DISCORD_CLIENT_SECRET);
}

app.get("/auth/discord", (req,res)=>{
  if(!discordConfigured()) return res.status(503).send("Discord login is not configured yet. Add DISCORD_CLIENT_ID and DISCORD_CLIENT_SECRET in Render.");
  const state = jwt.sign({nonce:crypto.randomBytes(16).toString("hex")}, JWT_SECRET, {expiresIn:"10m"});
  res.setHeader("Set-Cookie", `vortex_oauth_state=${state}; Max-Age=600; Path=/; HttpOnly; SameSite=Lax${process.env.NODE_ENV==="production"?"; Secure":""}`);
  const redirectUri = discordRedirectUri(req);
  const params = new URLSearchParams({
    client_id: DISCORD_CLIENT_ID,
    redirect_uri: redirectUri,
    response_type: "code",
    scope: "identify",
    state
  });
  res.redirect("https://discord.com/oauth2/authorize?"+params.toString());
});

app.get("/auth/discord/callback", async (req,res)=>{
  try {
    if(!discordConfigured()) return res.status(503).send("Discord login is not configured yet.");
    const {code,state} = req.query;
    const savedState = cookieValue(req, "vortex_oauth_state");
    if(!code || !state || !savedState || state !== savedState) return res.status(400).send("Invalid Discord login state.");
    jwt.verify(state, JWT_SECRET);
    const redirectUri = discordRedirectUri(req);
    const tokenResponse = await fetch("https://discord.com/api/v10/oauth2/token", {
      method:"POST",
      headers:{"Content-Type":"application/x-www-form-urlencoded"},
      body:new URLSearchParams({client_id:DISCORD_CLIENT_ID,client_secret:DISCORD_CLIENT_SECRET,grant_type:"authorization_code",code:String(code),redirect_uri:redirectUri})
    });
    if(!tokenResponse.ok) throw new Error("Discord token exchange failed");
    const tokens = await tokenResponse.json();
    const userResponse = await fetch("https://discord.com/api/v10/users/@me", {headers:{Authorization:`Bearer ${tokens.access_token}`}});
    if(!userResponse.ok) throw new Error("Could not read Discord user");
    const du = await userResponse.json();
    const username = String(du.global_name || du.username || `Discord-${du.id}`).slice(0,32);
    const avatar = du.avatar ? `https://cdn.discordapp.com/avatars/${du.id}/${du.avatar}.png?size=128` : "";
    let user = db.prepare("SELECT * FROM users WHERE discord_id=?").get(du.id);
    if(!user){
      const existing = db.prepare("SELECT * FROM users WHERE username=?").get(username);
      const safeUsername = existing ? `${username}-${String(du.id).slice(-4)}`.slice(0,32) : username;
      const randomPassword = await bcrypt.hash(crypto.randomBytes(32).toString("hex"), 10);
      const result = db.prepare("INSERT INTO users(username,password_hash,discord_id,avatar) VALUES(?,?,?,?)").run(safeUsername,randomPassword,du.id,avatar);
      user = db.prepare("SELECT * FROM users WHERE id=?").get(result.lastInsertRowid);
    } else {
      db.prepare("UPDATE users SET username=?,avatar=? WHERE id=?").run(username,avatar,user.id);
      user = db.prepare("SELECT * FROM users WHERE id=?").get(user.id);
    }
    const appToken = jwt.sign({id:user.id,username:user.username,discord_id:user.discord_id},JWT_SECRET,{expiresIn:"7d"});
    const secure = process.env.NODE_ENV === "production" ? "; Secure" : "";
    res.setHeader("Set-Cookie", [
      `vortex_oauth_state=; Max-Age=0; Path=/; HttpOnly; SameSite=Lax${secure}`,
      `vortex_token=${encodeURIComponent(appToken)}; Max-Age=${7*24*60*60}; Path=/; HttpOnly; SameSite=Lax${secure}`
    ]);
    res.redirect("/#/");
  } catch(err){
    console.error(err);
    res.status(500).send("No se pudo iniciar sesión con Discord. Intenta de nuevo.");
  }
});

app.post("/api/register", (req,res)=>res.status(410).json({error:"Vortex Customs usa Discord para iniciar sesión."}));

app.post("/api/login", (req,res)=>res.status(410).json({error:"Vortex Customs usa Discord para iniciar sesión."}));

app.post("/api/logout", (req,res)=>{ clearAuthCookie(res); res.json({ok:true}); });

app.get("/health", (req,res)=>res.json({ok:true,service:"vortex-customs"}));

app.get("/api/me", auth, (req,res)=>res.json({user:req.user}));

app.get("/api/matches", (req,res)=>{
  const rows = db.prepare(`
    SELECT * FROM matches
    WHERE visibility='public' AND status IN ('waiting','starting')
    ORDER BY id DESC LIMIT 100
  `).all();
  res.json(rows.map(publicMatch));
});

app.post("/api/matches", auth, (req,res)=>{
  const {
    title="Vortex Customs",
    mode="Battle Royale",
    team_size="Solo",
    build_mode="Build",
    region="NA East",
    visibility="public",
    max_players=100,
    custom_key=''
  } = req.body;

  const result = db.prepare(`
    INSERT INTO matches(host_id,title,mode,team_size,build_mode,region,visibility,max_players,custom_key)
    VALUES(?,?,?,?,?,?,?,?,?)
  `).run(req.user.id,title,mode,team_size,build_mode,region,visibility,Math.max(2,Math.min(100,max_players)),String(custom_key||'').slice(0,16));

  const match = db.prepare("SELECT * FROM matches WHERE id=?").get(result.lastInsertRowid);
  io.emit("matches:update");
  res.json(publicMatch(match));
});


app.get("/api/matches/:id", (req,res)=>{
  const row=db.prepare("SELECT m.*, u.username host_username FROM matches m JOIN users u ON u.id=m.host_id WHERE m.id=?").get(req.params.id);
  if(!row)return res.status(404).json({error:"Partida no encontrada."});
  const out=publicMatch(row); out.is_host=!!req.headers.authorization && (()=>{try{return jwt.verify(req.headers.authorization.replace('Bearer ',''),JWT_SECRET).id===row.host_id}catch{return false}})();
  if(row.visibility==='private' && !out.is_host && row.status!=='waiting') return res.status(403).json({error:"Partida privada."});
  res.json(out);
});

app.post("/api/matches/:id/join", auth, (req,res)=>{
  const match = db.prepare("SELECT * FROM matches WHERE id=?").get(req.params.id);
  if (!match || match.status !== "waiting") return res.status(404).json({error:"La partida no está disponible."});

  const count = db.prepare("SELECT COUNT(*) c FROM queue WHERE match_id=?").get(match.id).c;
  if (count >= match.max_players) return res.status(409).json({error:"La cola está llena."});

  try {
    db.prepare("INSERT INTO queue(user_id,match_id) VALUES(?,?)").run(req.user.id,match.id);
  } catch {}
  io.emit("queue:update", {matchId:match.id});
  io.emit("matches:update");
  res.json(publicMatch(match));
});

app.post("/api/matches/:id/leave", auth, (req,res)=>{
  db.prepare("DELETE FROM queue WHERE user_id=? AND match_id=?").run(req.user.id,req.params.id);
  io.emit("queue:update", {matchId:Number(req.params.id)});
  io.emit("matches:update");
  res.json({ok:true});
});

app.get("/api/matches/:id/queue", auth, (req,res)=>{
  const users = db.prepare(`
    SELECT u.id,u.username,q.joined_at
    FROM queue q JOIN users u ON u.id=q.user_id
    WHERE q.match_id=? ORDER BY q.id
  `).all(req.params.id);
  res.json(users);
});

app.post("/api/matches/:id/start", auth, (req,res)=>{
  const match = db.prepare("SELECT * FROM matches WHERE id=?").get(req.params.id);
  if (!match || match.host_id !== req.user.id) return res.status(403).json({error:"Solo el host puede iniciar."});
  db.prepare("UPDATE matches SET status='starting' WHERE id=?").run(match.id);
  io.emit("matches:update");
  res.json({ok:true});
});

io.on("connection", socket => {
  socket.on("match:join", id => { socket.join('match:'+Number(id)); });
  socket.on("chat:send", ({username,message,room='global'}) => {
    const clean=String(message||'').trim().slice(0,300); if(!clean)return;
    const payload={username:String(username||'Player').slice(0,32),message:clean,room:String(room),at:Date.now()};
    if(String(room)==='global') io.emit('chat:message',payload); else io.to(String(room)).emit('chat:message',payload);
  });
});

app.get("*", (req,res)=>res.sendFile(path.join(__dirname,"public","index.html")));
server.listen(PORT, "0.0.0.0", ()=>console.log(`Vortex Customs running on port ${PORT}`));
