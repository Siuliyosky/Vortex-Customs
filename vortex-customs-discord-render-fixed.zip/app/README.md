# Vortex Customs

Fortnite custom-match community site with Discord sign-in, public match board, queues, chat, and hosting controls.

## Deploy on Render

This project is a **Node/Express Web Service**, not a Static Site. Render Web Services are the correct type when the app needs server-side auth, APIs, Socket.IO, and a database.

### 1. Upload the project

Push this folder to GitHub, then create a Render **Web Service** from the repository.

- Build Command: `npm install`
- Start Command: `npm start`
- Health Check Path: `/health`

The included `render.yaml` contains these settings too. Render documents Node Web Services with `npm install`/`npm start` and requires the server to listen on the Render port.

### 2. Create/configure your Discord application

In the Discord Developer Portal, create an application and configure its OAuth2 redirect URL. The redirect URL must match the URL users will actually visit.

For a Render URL such as:

`https://vortex-customs.onrender.com`

use this exact redirect URL:

`https://vortex-customs.onrender.com/auth/discord/callback`

If you use a custom domain, use that domain instead.

### 3. Add Render environment variables

In Render → your service → Environment, add:

- `DISCORD_CLIENT_ID` = your Discord Application ID
- `DISCORD_CLIENT_SECRET` = your Discord OAuth2 client secret
- `JWT_SECRET` = a long random secret
- `NODE_ENV` = `production`

`DISCORD_REDIRECT_URI` is optional. If you leave it blank, Vortex automatically builds the callback URL from the public Render request. Setting it explicitly is recommended for a fixed production domain.

Do **not** put the Discord client secret in `public/index.html` or commit a real `.env` file.

### 4. Redeploy

After saving the variables, deploy/redeploy the service. Open:

`https://YOUR-RENDER-DOMAIN.onrender.com/health`

It should return a small JSON health response. Then open the site and click **Continue with Discord**.

## How Discord login works in this version

1. Vortex sends the browser to Discord OAuth2.
2. Discord sends the browser back to `/auth/discord/callback`.
3. Vortex exchanges the authorization code on the server.
4. Vortex creates/updates the local user linked to the Discord ID.
5. Vortex stores its own signed login token in an HttpOnly cookie.
6. The browser returns to the normal Vortex home page, without putting the login token in the URL.

This avoids the previous `discord_token` query-string flow and also makes the login work with Render's HTTPS proxy.

## Local development

Copy `.env.example` to `.env` and fill in the Discord values. Then run:

```bash
npm install
npm start
```

For local OAuth, the Discord application must also have your local callback URL registered, for example `http://localhost:3000/auth/discord/callback`.

## Important Fortnite note

The website manages the community match page, queue, chat, and host settings. A real Fortnite private/custom lobby still requires an authorized Fortnite/Epic mechanism; the website does not pretend to generate an unauthorized Fortnite custom key.
